
extends= testmypy.pl

@ docodeatester.py [code.py]

# Just build it 

