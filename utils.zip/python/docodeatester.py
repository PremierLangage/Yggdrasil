
def g():
    """
    >>> g()
    3
    >>> g()
    4
    """
    return 3

"""
Ceci est un doc 

>>> f() == 3
True
>>> f() == 4 
False
"""


