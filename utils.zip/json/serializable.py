
class Serializable:
    pass