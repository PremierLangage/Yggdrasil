# OCE 10/09/2019 : KO

# Copyright 2016 Dominique Revuz <dr@univ-mlv.fr>

name=  python/iut/template.pl

grader==
from utils import grade
grade()
==

sandbox=@/pysrc/src/plutils.py


