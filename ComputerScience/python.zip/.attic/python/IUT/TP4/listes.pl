# OCE 10/09/2019 : KO

# Copyright 2016 Dominique Revuz <dr@univ-mlv.fr>
author=Dominique Revuz 

title= Manipulation de Liste
tag= list|indices|slices
template=plbank:/python/0PLG/template
text==

Calcul du max 

==

code==

l=
print("Question 1")
print(l)


==

expectedoutput==

==



