# OCE 10/09/2019 : KO

oneshot=True

author=dr

template=plbank:/python/0PLG/template

title=  la boucle While

jinjatext==

Ecrire une boucle while qui réalise la description suivante :


    {{ text }}

Attention pas de boucle for ;)

==

build=@repoplbase:python/IUT/DynaWhile/dynawhile.py


needed=while
taboo=for

