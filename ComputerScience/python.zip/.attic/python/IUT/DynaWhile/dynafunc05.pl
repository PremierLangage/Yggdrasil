# OCE 10/09/2019 : KO

oneshot=True

author=dr

template=plbank:/python/0PLG/template

title=Une fonction  

jinjatext==

{{ text }}

N'oublier pas la fonction d'affiche rien.
==

build=@repoplbase:python/IUT/DynaWhile/randomfuncs.py

code==
def f(bas,haut):
...
    return None
==



