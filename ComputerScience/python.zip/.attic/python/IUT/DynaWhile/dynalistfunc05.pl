# OCE 10/09/2019 : KO

oneshot=True

author=dr

template=plbank:/python/0PLG/template

title=Une fonction et une liste 

jinjatext==

{{ text }}

==

build=@repoplbase:python/IUT/DynaWhile/listfuncs.py

code==
def f(l):
    
    return None
==




