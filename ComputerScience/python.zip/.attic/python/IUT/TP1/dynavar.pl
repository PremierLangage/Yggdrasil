# OCE 10/09/2019 : KO

template=plbank:/gift/template/short_template.pl

title= Evaluer

jinjatext==

# Evaluer une suite d'instructions 

Soit le code python suivant quel est la valeur de la variable **a** après l'exécution des lignes suivantes :


    {{ code }}


==

build=@repoplbase:python/IUT/TP1/dynabuild.py


