# OCE 10/09/2019 : KO

# Copyright 2016 Dominique Revuz <dr@univ-mlv.fr>
author=Dominique Revuz 
name= Erreur de compilation 
title= Erreur de compilation 
tag=compile|error
template=plbank:/python/0PLG/soluce



text==

# Erreurs de Compilation

Corrigez l'erreur qui fait que le code suivant ne compile pas. 

==

code==

y=2
 print("une douzaine :",y*6)

==

# Choisir pltest ou soluce ou expectedoutput
expectedoutput=une douzaine : 12

help==

Oui il faut indenter de la même facon des lignes de code qui se suivent. 

==

