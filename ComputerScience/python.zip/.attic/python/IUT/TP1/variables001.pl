# OCE 10/09/2019 : KO

template=plbank:/gift/template/short_template.pl

title=Short

text==

Soit le code python suivant quel est la valeur de la variable **a** après l'exécution des lignes suivantes :

  a=1
  b=2
  a=b**a
  b=a
  a=b*b

==


answer1=4

answer2=quatre


feedback1= Très bien ** est le caractère pour l'exponentiation

feedback2=Correct, mais une version entière : 4 serait plus judicieuse  

