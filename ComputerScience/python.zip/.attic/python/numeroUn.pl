
# Bonjour,
# bienvenu sur la plateforme d'exercice PL
# la courbe d'apprentissage est un peu brutale au début 
# ne vous décourager pas avant d'avoir écrit un exercice de programmation 
# Merci
# Dominique 


# Dessous un exercice VraiFaux


template=plbank:/gift/template/truefalse_template.pl


author=Moi Meme # Changer moi cela s'il vous plait ;)

title= Exercice Numero Un

text==

Irma est le nom d'un Cyclone qui a parcourru les Caraibes et la Floride en 2017 (vrai/faux) ?

==

answer=True

feedback=Excellent quelle mémoire !


