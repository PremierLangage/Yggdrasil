# OCE 11/09/2019 : KO

# Fait par Boris Jabot

oneshot=True

extends=/ComputerScience/python/template/suitesoluce.pl
# OCE 11/09/2019 : KO lancé en solo

@ builder.py [builder.py]

soluce==
==

text==
==

code==
==

plsoluce==
Exo Boucle while |
==


