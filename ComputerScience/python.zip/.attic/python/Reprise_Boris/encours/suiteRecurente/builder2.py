import sys, json, jsonpickle
from random import randint
from math import exp

def generateAleaExo():
    u0 = randint()
