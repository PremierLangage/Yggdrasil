# OCE 10/09/2019 : OK

extends=template.pl

difficulty=3
taboo=while
needed=for

text= Pour ne pas avoir un warning stupid

plsoluce==
Exo Boucle for |
==

