# OCE 10/09/2019 : OK

extends=template.pl

difficulty=3
taboo=for
needed=while


