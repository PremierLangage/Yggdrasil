# OCE 11/09/2019 : lancé en solo et KO
# Fait par Boris Jabot

oneshot=True

extends=/ComputerScience/python/template/loopsoluce.pl
@ builder.py [builder.py]

title=Boucle {{needed}} - difficulté {{difficulty}}

doc==
text et soluce ne doivent être remplis que si on ne souhaite pas utiliser cet exercice
en exercice aléatoire.
==

soluce==
==

text==
==

code==
==










