# OCE 11/09/2019 : KO lancé en solo

# Fait par Boris JABOT

oneshot=True

extends=/ComputerScience/python/template/timesoluce.pl

title=Time Exo

grader  =@ /grader/evaluator.py

