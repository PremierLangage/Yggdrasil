# OCE 11/09/2019 : OK

extends=template.pl

pltest==
>>> convertStoH(56165)
(15, 36, 5)
==

text==
Écrire une fonction <strong><I>convertStoH</I></strong> qui convertit une durée en secondes en une durée en heures, minutes, secondes.
==


