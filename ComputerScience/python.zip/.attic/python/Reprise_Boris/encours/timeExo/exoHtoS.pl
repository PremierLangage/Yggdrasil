# OCE 11/09/2019 : OK

extends=template.pl

pltest==
>>> convertHtoS(15, 36, 5)
56165
==

text== #|html|
Écrire une fonction <strong><I>convertHtoS</I></strong> qui convertit une durée en heures, minutes, secondes en une durée en secondes.
==


