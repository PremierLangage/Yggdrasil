# OCE 10/09/2019 : OK

extends=template.pl

#FIXME see doc below

doc==

attention cet exo ne vérifie pas l'existance 
des variables demandées et fait une erreur 
d'éxcution au lieux de faire un message à
l'élève

==

