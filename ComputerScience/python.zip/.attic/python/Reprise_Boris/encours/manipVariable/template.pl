# OCE 10/09/2019 : OK mais c'est un template qui produit la mêême chose que Exo.pl juste au dessus dans le même fichier

# Fait par Boris Jabot

oneshot=True

extends=/ComputerScience/python/template/manipvarsoluce.pl
@ builder.py [builder.py]

soluce==
==

text==
==

title=Exo manipultation de variables

code==
==

var==
==

plsoluce==
Exo Manipulation de variables |
==








