


#  ceci est un fichier de test oublier le 

extends=/template/qcm_template.pl


author=Moi Meme # Changer moi cela s'il vous plait ;)

title= Exercice Numero Un
# la ligne suivant possai ds problèmes au parseur 
 	
text==

Irma est le nom d'un Cyclone qui a parcouru les Caraibes et la Floride en 2017 (vrai/faux) ?

==

good=Vrai
bad=Faux

feedback=Excellent quelle mémoire !



