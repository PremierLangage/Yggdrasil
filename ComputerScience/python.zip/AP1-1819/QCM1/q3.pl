
extends=/ComputerScience/python/template/qcm_template.pl

title=Question 3


text=Parmi les mots suivants lesquels sont des mots réservés de python ? 


nb=4
nbtrues=2
uncrosedfalse=
good==
and
del
from
not
while
as
elif
global
or
with
assert
else
if
pass
yield
break
except
import
print
class
exec
in
raise
continue
finally
is
return
def
for
lambda
try
==

bad==
slice
accept
include
stop
slice
make
concat
add
push
recall
call
elsif
todo
next
up
down
run
==

feedback=show


