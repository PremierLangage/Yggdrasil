
extends=/ComputerScience/python/template/qcm_template.pl

title=Question 6 
doc==

Concatenation
==
tag=concatenation|str

text==
Qu'affiche le code suivant :

        str_1 = "Bonjour"
        str_2 = ’ici’
        bob = str_1 + str_2
        print(bob)


==

nb=4
nbtrues=1
uncrosedfalse=
good==
Bonjourici
==

bad==
0
Rien
Bonjour
ici
Bonjour ici
==

feedback=show

