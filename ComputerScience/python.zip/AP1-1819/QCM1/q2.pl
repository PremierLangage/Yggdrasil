
extends=/ComputerScience/python/template/qcm_template.pl

title=Question 1


text=Parmi les mots suivants lesquels sont valides pour un nom de variable ?


nbtrue=2
nb=4
uncrosedfalse=
good==
abc
HellO
s33d
_upem_
vraie
faux
true
fonction
function
false
opositif
==

bad==
O positif
f()
True
False
def
Hello!
Salut les terriens
6six6
777
737Max
l[]
aujourd'hui
après-demain
rendez-vous
O+
==

feedback=show


