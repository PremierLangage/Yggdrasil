
extends=/ComputerScience/python/template/qcm_template.pl

title=Commentaires 7


text= Indiquez les lignes qui sont des commentaires en python :



nb=4
nbtrues=1
uncrosedfalse=
good==
# Ceci est un commentaire 
==

bad==
[*  Ceci est un commentaire  *]
/*  Ceci est un commentaire */
//  Ceci est un commentaire 
@  Ceci est un commentaire 
@@  Ceci est un commentaire  @@
:param  Ceci est un commentaire 
REM  Ceci est un commentaire 
COMMENT:  Ceci est un commentaire 
==

feedback=show

