
extends=/ComputerScience/python/template/qcm_template.pl

title=Question 5


text= En python 3, quelle est la meilleure description caractérisant la fonction input ?

nb=4
nbtrues=1
uncrosedfalse=
good==
C'est une fonction prédéfinie.
C'est une fonction prédéfinie de lecture de l'entrée standard.
==

bad==
C'est une fonction utilisateur (définie par l').
C'est une fonction de calculs aléatoires.
C’est une structure de données qui peut contenir plusieurs valeurs accessibles grâce à des clés dont le type est une chaine de caractères.
C’est un mot clé du langage.
==

feedback=show



