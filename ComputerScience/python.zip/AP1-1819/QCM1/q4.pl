
extends=/ComputerScience/python/template/qcm_template.pl

title=Question 4


text=En python 3, que réalise la fonction input ?

nb=4
nbtrues=1
uncrosedfalse=
good==
Elle interromps le programme et lit une chaine de caractères entrées par l’utilisateur.
Elle met le programme en attente d'une saisie au clavier et retourne celle-ci.
==

bad==
Elle met fin au programme et retourne une valeur de fin.
Elle lit une partie de la mémoire du programme en cours d’exécution.
Elle affiche un texte et retourne None.
Elle réalise une impression écran de l’écran actuel.
Elle se traduit par non-pose (in négation, put verbe poser).
==

feedback=show


