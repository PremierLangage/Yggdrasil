

# Contenu de la premiere semaine 

 ** Valeurs Variables Types**


# Valeurs 

Exercices aleatoire quelques valeurs :
Objectif faire saisir des valeurs entiere en utilisant un des format 
Decimal, Octal , Binaire, Hexa, 

nombre aleatoire multiple de 2 entre 2 et 20 
format aleatoire DOBH

verification le bon caractere de format est present la valeur est identique a celle cherche 


# Quelques operations 

Idee on a une formule du genre 

0x1 OP 12 = 0xC

Il faut deviner quel est l'operateur entre *+-//** etc.
Un bonton a saisir ??


Le format des valeurs utilisee est tire aleatoirement les valeurs reste en 2 et 20.
Les operations sont prisent dans une liste [ '+','-','*','//']

# Quelques operations sur la chaines  

On a des resultats d'operations sur deux chaines.

exemple: chaines "un" et "deux" 

'ununun' ("un"+'un"+"un")
'ununun' ("un"*3)
'undeux' ("un" + "deux")
'un' ("un"*1+"deux"*0) 

'un' + str(4)
'deux' * str(4)

Des paires de valeurs et equations a apariller 

