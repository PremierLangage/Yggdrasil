

@ /utils/sandboxio.py
grader  =@ /grader/evaluator.py
builder =@ /builder/before.py

nbechec%0

before== #|python|
import random
essai = 4
N = 6
op1 = [str(random.randint(1, 3)) for n in range(N)]
op2 = [str(random.randint(1, 10)) for n in range(N)]
ope = [random.choice(['/','//','%','**']) for n in range(N)]
res = [ eval(op1[n]+ope[n]+ op2[n]) for n in range(N)]
solved=[ False for n in range(N)]
inputs = []
for i in range(N):
    inp = Input()
    globals()[f"input{i}"] = inp
    inputs.append(inp)
==

evaluator== #|python|

cpt = 0
for i in range(N):
    box = globals()[f"input{i}"]
    if solved[i]:
        cpt += 1
    elif box.value == str(res[i]):
        cpt += 1
        solved[i]= True

score = int(cpt / N * 100)
feedback = 'Bravo' if score == 100 else 'Corriger les erreurs'
essai -= 1 if score != 100 else 0
if score <100 and essai<1 :
    exec(before)
    nbechec += 1
    feedback ="essayez avec d'autres valeurs nombre d'echec= "+str(nbechec)
grade = (score, feedback)
==

title = Expressions aléatoires
# y a pas besoin d'énoncé 
text==
Attention vous avez un nombre limité d'essai pour répondre a toutes les égalitées.

Sinon cela redémarre au début avec {{N}} égalités.

Oui heureusement il y en a des faciles...

**Attention il faut fournir une valeur numérique sur chaque ligne.**
==

form== #|html|
Nombre d'essais : {{essai}}
<ul>
{% for input in inputs %}
{% if not solved[loop.index0]%}
<li>  {{op1[loop.index0]}}  {{ope[loop.index0]}}  {{op2[loop.index0]}}   = {{ input|component }}  </li>
{% endif %}
{% endfor %}
</ul>
==
