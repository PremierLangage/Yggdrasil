
extends=qcm.pl



wrong==
non | 
faux | 
pas vrai 
==

right==
oui | Evidement
yes | Car c'"est vrai 
oui oui| par ce que oui oui
==

