author= Emmanuel

# comment
extends=/ComputerScience/python/AP1-1920/templates/pltest.pl

title = Produit

text == 
Réaliser une fonction s'appelent "produit" qui prend comme arguments deux nombres et retourne leur produit.

==

pltest==
>>> produit(2,4)
8
>>> produit(0,4)
0

==


