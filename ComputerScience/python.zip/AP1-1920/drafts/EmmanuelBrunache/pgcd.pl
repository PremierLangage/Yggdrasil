author= Emmanuel

# comment
extends=/ComputerScience/python/AP1-1920/templates/pltest.pl

title = PGCD

text == 
Réaliser une fonction s'appelant "pgcd" qui prend deux arguments entiers strictement positifs et qui détermine le pgcd de ceux-ci.

{{pltest}}
==

taboo=import

pltest==
>>> pgcd(2,4)
2
>>> pgcd(18,27)
9

==



