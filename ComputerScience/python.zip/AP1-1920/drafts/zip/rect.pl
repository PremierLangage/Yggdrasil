


author zip

# Heritage d'un type d'exercice 
extends=../../templates/pyeditor.pl


before==

lg=3
larg=5

==

text== les dimensions d'un rectangle sont mémorisées dans des variables lg et larg.
ecrire un programme qui calcule et affiche le périmètre et la surface du rectangle


evaluator==




