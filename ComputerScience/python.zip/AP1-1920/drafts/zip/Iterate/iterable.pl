title= 

@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/comptemot.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/crypte.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/dames.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/iterable.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/join.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/permutcirc.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/simplifdigit.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/Suite_de_Conway.pl
@ /ComputerScience/python/AP1-1920/drafts/zip/Iterate/voyelle.pl
@ /ComputerScience/python/AP1-1920/drafts/dominique/iterables/lili.pl
@ /ComputerScience/python/AP1-1920/drafts/dominique/iterables/suffixe.pl
@ /ComputerScience/python/AP1-1920/drafts/dominique/iterables/bord.pl
@ /ComputerScience/python/AP1-1920/drafts/dominique/iterables/echange.pl

