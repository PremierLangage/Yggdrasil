# OCE : test 24/10/2019 OK

author=AO
title= valeure absolue d'un nombre.

extends=/ComputerScience/python/AP1-1920/templates/pltest.pl

text==

Ecrivez une fonction absolue qui demande un nombre à l’utilisateur et affiche sa valeur absolue
==
pltest==
>>> absolue(-4)
4
>>> absolue(4)
4
==

