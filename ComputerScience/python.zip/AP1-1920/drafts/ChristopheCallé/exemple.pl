extends=../../templates/pltest.pl

title=Un exemple

text==
Déclarez une variable `a` qui contient True
==

pltest==
>>> a == a
True
==

pltest1==
>>> a
True
==

