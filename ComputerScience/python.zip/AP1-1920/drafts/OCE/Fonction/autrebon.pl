
extends=Le_bon_code.pl

@ toto.py [base.py]

