##BEGIN
def f():
    pass
##END
##BEGIN
def main():
    f()
    g()
##END
##BEGIN
main()
##END
##BEGIN
def g():
    pass
##END

