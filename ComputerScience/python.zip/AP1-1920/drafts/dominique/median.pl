

tags=list|median

doce==
Summary: The median of a set of data is the middlemost number in the set.
 The median is also the number that is halfway into the set. 
 To find the median, the data should be arranged in order from least to greatest. 
 If there is an even number of items in the data set,
  then the median is found by taking the mean (average) of the two middlemost numbers.
==


