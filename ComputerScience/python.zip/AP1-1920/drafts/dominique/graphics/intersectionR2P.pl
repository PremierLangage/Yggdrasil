
@ rect-2-points.png [image.png]


text==

Ecrire une fonction **disjoints(p1,p2,p3,p4)** permettant de tester si (bool) oui ou non le deux rectangle sont disjoints.
On suppose que p1=(x1,y1) et pi=(xi,yi) confrormément au dessin si dessous.

<img src="image.png" width="25%" >

==


