



# Heritage d'un type d'exercice 
extends=../../templates/pyeditor.pl


before==


==



evaluator==

grade=(100," bravo")


==
