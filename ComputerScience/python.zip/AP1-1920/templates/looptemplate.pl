
# DR : test 5/10/2019 OK. 



oneshot=True

extends=/ComputerScience/python/template/loopsoluce.pl
@ loopbuilder.py [builder.py]

doc==
FIXME je ne comprend pas cette doc DR
text et soluce ne doivent être remplis que si on ne souhaite pas utiliser cet exercice
en exercice aléatoire.
==

soluce=
text=






