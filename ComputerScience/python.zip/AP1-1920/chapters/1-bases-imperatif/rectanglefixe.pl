
author=zip

# Heritage d'un type d'exercice 
extends=/ComputerScience/python/template/soluce.pl

title = Rectangle fixe


text== 
Les dimensions d'un rectangle sont 3 et 7.

Ecrire un programme qui calcule et affiche le périmètre et la surface du rectangle
sous la forme :

le périmètre est ?? et la surface est ??.
==
code==
"le périmètre est ?? et la surface est ??."
==

soluce==
print("le périmètre est 20 et la surface est 21.")
==

plsoluce==
Le test |le périmètre est 20 et la surface est 21.
==




