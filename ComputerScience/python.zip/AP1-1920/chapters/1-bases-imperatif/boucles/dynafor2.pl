
# DR j'ai fixé la seed dans cet exercice  
# il est donc statique

extends=../../../templates/looptemplate.pl


exoseed % 7
difficultymax=2
taboo=while
needed=for

title=Boucle for N° 2

text= Pour ne pas avoir un warning stupid

plsoluce==
Vérification du comportement fixé |
==





