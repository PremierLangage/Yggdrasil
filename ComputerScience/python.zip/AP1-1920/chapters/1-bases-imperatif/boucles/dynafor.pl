
# DR j'ai fixé la seed dans cet exercice  
# il est donc statique

extends=../../../templates/looptemplate.pl



difficulty=2
taboo=while
needed=for

title=Boucle for (répétable)

text= Pour ne pas avoir un warning stupid

plsoluce==
Vérification du comportement fixé |
==





