
# DR j'ai fixé la seed dans cet exercice  
# il est donc statique

extends=../../../templates/looptemplate.pl


exoseed % 3
difficultymax=1
taboo=while
needed=for

title=Boucle for 

text= Pour ne pas avoir un warning stupid

plsoluce==
Vérification du comportement fixé |
==


