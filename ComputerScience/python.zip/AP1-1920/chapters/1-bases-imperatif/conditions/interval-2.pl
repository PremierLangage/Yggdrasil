

extends= interval_inputs.pl

niveau % 2

