

# this is a template

form==
<div class="input-group">
    <input id="form_txt_answer"  class="form-control" placeholder="" style="weigth:150" required>
</div>
==

