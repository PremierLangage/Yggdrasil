extends=/ComputerScience/python/template/qcm_template.pl

doc==

Il suffit de définir le contenue de la balise text puis 
si elle est vraie :
good=Affirmation Vraie
bad=Affirmation Fausse 
si elle est fausse : 
bad=Affirmation Vraie
good=Affirmation Fausse 



==

good=Affirmation Vraie
bad=Affirmation Fausse 
