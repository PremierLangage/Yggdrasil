
@ loopevaluator.py          [grader.py] 
@ gradesoluce.py
@ /utils/sandboxio.py
@ /builder/none.py [builder.py]
@ feedback2.py
@ template.html


# une interface standard d'exercice avec un editeur pour la réponse
form=@ /python/form/editorform.html

settings.allow_reroll=1



