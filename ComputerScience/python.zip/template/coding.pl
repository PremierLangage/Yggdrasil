

# FIXME  TODO
# DR ne pas utiliser 
# il rest de exos basé dessus mais ils doivent être modifiés

# Template d'exercice de programmation python

# todo corriger ce template 

grader==
from plgrader import Grader
print(Grader().grade())
==

@/pysrc/src/__init__.py
@/pysrc/src/plgrader.py
@/pysrc/src/feedback.py
@/pysrc/src/plutils.py
@/pysrc/src/pldoctest.py
@/pysrc/src/template.html

@ /utils/sandboxio.py
@ /builder/none.py [builder.py]


# une interface standard d'exercice avec un editeur pour la réponse
form=@ /python/form/editorform.html







