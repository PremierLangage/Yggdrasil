
# Pour un exercice avec un simple evaluator

@ /utils/sandboxio.py
@ /builder/before.py [builder.py]
@ /grader/evaluator.py [grader.py]

title== #|python| 

==
text== #|python| 

==
form== #|python| 

==
before== #|python| 

==
