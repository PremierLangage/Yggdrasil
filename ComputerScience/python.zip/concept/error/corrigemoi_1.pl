# Boris Jabot 10/09/2019 OK
author=Dominique Revuz

tag=error
title= Corrige Moi !
name= x ?
extends=/ComputerScience/python/template/soluce.pl
text==

Le programme python si dessous contient une erreur corrigez la pour passer à l'exercice suivant.

==

code==
x1=2
y2=5
z=x1+x2
print(z)
==

success==
<p> Parfait passez à l'exercice suivant </p>
==

soluce==
x1=2
y2=5
z=x1+y2
print(z)
==

plsoluce==
Correction de l'erreur de compilation | rien à lire
==




