

___doc__="""
1) Le nom de variable inconnu.
2) appel de fonction sans paranthèse : 
- print 
- input 
3) Erreur sur la ligne au dessus, 
3.1) paranthèse manquante 
3.2) fin de chaine manquante
3.3) pas de : après else for etc.
4) Erreur sur l'utilisation de " et ' 
4.1) Une chaine pas entre quote 
4.2) Un entier entre quote 
4.3) Une quote au milieu d'une chaine entre quote ou guillemet et guillemets.


"""
def createexo():
    return "a=x+y","a=2+3"," Si x et y sont inconnues on ne peut compiler cette ligne. Soit vous ajouter une définition soit vous changer les paramètres de l'addition."
