# OCE : test 11/09/2019 OK
 
 # The template default will not be neccessary in the futur 
extends=/template/default.pl

title=  Une question ouverte 

text== 

Une petite zone de texte pour donnez vos idées sur cette page d'exercices.

- appréciation générale 
- vos remarques sur l'orthographe sont à faire ailleurs.
- des idées d'exercice sur le thème
  

<a href="/ask/"> le Q&A lien direct </a>.

<small>le mont blanc vue de l'aiguille du midi.</small>
==


extracss==
<style>
.exercise__header {
background: center no-repeat url("https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/PanoMontBlancHDR_edit_1.jpg/800px-PanoMontBlancHDR_edit_1.jpg");
background-size: contain;
}
</style>
==



 









