# OCE : test 11/09/2019 KO

author=DR
title= Initialisation d'une variable.
tag=variable
text==

Initialisation d'une variable.

	Intialisez la variable X avec la chaine Toto.

==

code==

==

# comme ca cela se passera bien
pltest==
>>> X=="Toto"
True
==

extends=/ComputerScience/python/template/coding.pl






