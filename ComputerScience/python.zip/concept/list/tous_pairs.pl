
title= Liste entiers pairs
extends=/ComputerScience/python/template/pltest.pl

text==

Ecrire une fonction **tous_pairs** qui prend une liste en paramêtre et qui
retourne si tout les entiers sont pairs.


==

pltest==
>>> tous_pairs([2,4,5,6,77])
False
>>> tous_pairs([])
True
>>> import random #
>>> l=[ random.randint(1,100)*2 for x in range(10)] #
>>> tous_pairs(l)
True
>>> tous_pairs([ x+1 for x in l])
False
==

