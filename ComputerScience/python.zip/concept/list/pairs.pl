
title= Sous suite des pairs
extends=/ComputerScience/python/template/pltest.pl

text==

Ecrire une fonction **pairs** qui prend une liste en paramêtre et 
qui retourne une liste des entiers pairs de la liste.

==

pltest==
>>> pairs([2,4,5,6,77])
[2, 4, 6]
>>> pairs([])
[]
>>> import random #
>>> l=[ random.randint(1,100)*2 for x in range(10)] #
>>> pairs(l) == l
True
>>> pairs([ x+1 for x in l])
[]
==


