author=La Fontaine

extends=/ComputerScience/python/template/pltest.pl

title= La fonction, la  liste et le calcul 

builder=@ /builder/build.py
build=@ listfuncs.py

code==
def f(l):
    
    return None
==

