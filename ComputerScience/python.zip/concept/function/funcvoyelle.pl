# Boris Jabot 11/09/2019 OK
# Copyright 2016 Dominique Revuz <dr@univ-mlv.fr>
author=Dominique Revuz 
name= Function Voyelles
title=Function Voyelles
piste=verte
extends=/ComputerScience/python/template/pltest.pl
text==
# Appartient

Ecrire une fonction **voyelles** qui compte le nombre de voyelles (minuscules, sans accents) dans une chaîne de caractères passée en argument.

==

code==
# les voyelles :  aeiouy

==


pltest==
>>> voyelles("aeiouy")
6
>>> voyelles("ceci est un exemple")
7
>>> voyelles("")
0
>>> voyelles("zrt&(§ç&!'§(&!'è(ç")
0
==


