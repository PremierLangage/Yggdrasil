#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  testsimplefuncgrader.py
#  
from functiongrader import grade
__doc__=""">>> from student import foobar
>>> foobar(3)
'Fizz'
>>> foobar(7)
'Buzz'
>>> foobar(22)
'Fizz Buzz'
>>> foobar(11)
>>> 
"""
grade()
