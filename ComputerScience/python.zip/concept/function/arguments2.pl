
doc==
L'idée est de parler de *args et **dict comme argument de fonctions.

==

title= Arguments Multiples 

text==

