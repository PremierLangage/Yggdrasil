

def voyelles (u ) :
	return len ( [ c for c in u if c in "aeiou" ] )
