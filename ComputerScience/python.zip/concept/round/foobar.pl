# OCE : test 11/09/2019 KO

extends=/ComputerScience/python/template/coding.pl

title= Exo de Debug de pltest

before==


pltest='''
>>> f()
4
'''

text="""
ecrire la fonction f qui retourne 4
"""


==

