
# Round

plusieurs thematique sur les arroundis,

y a floor et ceil et round cela permet de faire des exercices 
ou la valeur rechercher est approche par le haut le bas ou arroundie.

# exemple 

racineCarre / racine Cubique / racine nieme 

Le premier entier telque 
    r**r <= n < (r+1)*(r+1) 
ou 
       r**r < n <= (r+1)*(r+1) 
ou
      r telque delta = abs(n-r*r) est minimal
       