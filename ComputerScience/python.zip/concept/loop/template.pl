# OCE : test 12/09/2019 OK. Template lancé en solo ça n'a pas de sens mais c'est un test fichier par fichier

# Fait par Boris Jabot

oneshot=True

extends=/ComputerScience/python/template/loopsoluce.pl
@ loopbuilder.py [builder.py]

doc==
text et soluce ne doivent être remplis que si on ne souhaite pas utiliser cet exercice
en exercice aléatoire.
==

soluce==
==

text==
==

code==
==

difficulty==
==


