# OCE : test 12/09/2019 OK

extends=template.pl


seed%17
difficultymax=3
taboo=while
needed=for

title=Boucle for 

text= Pour ne pas avoir un warning stupid

plsoluce==
Exo Boucle for |
==




