# OCE : test 12/09/2019 OK

extends=template.pl

difficultymax=3
taboo=for
needed=while

title=Boucle while


plsoluce==
Exo Boucle while |
==




