

Cet exercice doit êêtre terminé seule le code python des deux fichier afunc.py et interval.py contiennent quelque chose d'nteretssant.

