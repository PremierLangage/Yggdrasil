title= du Vrai et du faux
tag=bool|True|False

text==

## Un exercice très facile pour finir:   

les booléens en python sont True et False, et pas true et false.

==

extends=/ComputerScience/python/template/vraifaux.pl


