# Copyright 2017 Dominique Revuz <dr@univ-mlv.fr>
author=Dominique Revuz 
name=Tri de trois
title=Tri de trois
tag= if|else

extends=/ComputerScience/python/template/soluce.pl
text==

### Plus difficile 

Votre programme doit saisir trois entiers puis les afficher dans l'ordre, un par ligne.

==

# Choisir pltest ou soluce ou expectedoutput
code==
# voici trois entiers a afficher dans l'ordre croissant 
a,b,c=input().split(' ')
a,b,c=int(a),int(b),int(c)
# modifier le code dessous 


print(a)
print(b)
print(c)
==

soluce==
a,b,c=input().split(' ')
a,b,c=int(a),int(b),int(c)
l=[a,b,c]
ss= sorted(l)
for x in ss:
    print(x)
==


plsoluce==
Test1 b c a|10 17 8
Test2 a c b|5 77 6
Test3 c a b|18 8 17
Test4 c b a|2 1 0
Test5 a b c|1 4 8
Test6 b a c|23 9 122
==





