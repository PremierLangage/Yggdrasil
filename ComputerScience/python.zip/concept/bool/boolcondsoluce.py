poid=int(input())
if poid>20:
	print("Il y a un supplément de 30 euros pour un bagage de plus de 20 kilos.")
