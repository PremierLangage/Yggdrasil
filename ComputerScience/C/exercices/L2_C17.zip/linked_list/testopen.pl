


extends= /ComputerScience/C/exercices/L2_C17/file/test_open_file.pl

astuces==
[]
==


author= Examen 19 Juin 2023
