


extends=/template/default.pl


text==

La section teste des généralités 

==
title = Section bases 
form=




