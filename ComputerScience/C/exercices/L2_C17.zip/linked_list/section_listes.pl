







extends=/template/default.pl


text==

La section suivante est consacrée aux listes Chainées. 

**ATENTION les types de liste peuvent changer d'un exercice à l'autre**



==
title = Section Listes
form=


