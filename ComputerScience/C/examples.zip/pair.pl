extends=template.pl

title=Pair ou impair

text==
Coder une fonction Python `fonction_eleve` qui prend un 
seul argument supposé être un entier et return `True` si
l'argument est pair et `False` si l'argument est impair.
==

data1=1
expected1=0
data2=42
expected2=1

