criteria=surjectives

extends=/ComputerScience/C/examples/inj_surj_conseils/inj_surj_bij.pl

criteria=surjectives

title=Fonctions surjectives
