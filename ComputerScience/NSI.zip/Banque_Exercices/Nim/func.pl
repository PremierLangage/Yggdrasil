




extends = /ComputerScience/python/template/pltest.pl

title= Distribution 

text==


Ecrire une fonction **{{funcname}}** qui vérifie le doctest suivant :

{{doctest}}


==

editor.code==
==

pltest==
>>> deal([],3)
>>> deal([(1,2),(3,4)],1)
[(1,2)],[(3,4)]
==


