extends=  /ComputerScience/NSI/AMC/QCM-AMCE.pl 

questions==


==

@ questions_sample.txt [question1.txt]