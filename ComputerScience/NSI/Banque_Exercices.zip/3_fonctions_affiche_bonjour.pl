author=Emmanuel Brunache
name= Affiche bonjour
title= Affiche bonjour # N'oubliez pas de remplir ce champs svp
tag=def|parameters|return # N'oubliez pas de remplir ce champs svp
extends=/ComputerScience/python/template/pltest.pl
piste=verte
text==

Écrire une fonction **affiche_bonjour()** qui ne prend aucun argument, ne retourne rien mais affiche `bonjour`.

Exemple :

    >>> affiche_bonjour()
    bonjour

==

pltest==
    >>> affiche_bonjour()
    bonjour
==


testcode==
def affiche_bonjour():
    print('bonjour')
==

editor.code==
==





