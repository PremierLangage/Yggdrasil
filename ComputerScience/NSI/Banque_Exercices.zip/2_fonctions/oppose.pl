extends = /ComputerScience/NSI/templates/pltest/pltest2023.pl

title= Opposé 

text==
Ecrire une fonction **oppose** qui vérifie le doctest suivant :

    Cette fonction renvoie l'opposé de nombre (int ou float) passé en paramètre

    >>> oppose(8)
    -8
    >>> oppose(-123)
    123


==

befor ==
==


editor.code==
==

pltest==
>>> oppose(8)
-8
>>> oppose(-123)
123
>>> oppose(0)
0
==

