form=@ /form/text_editor.html

title = Codage de Huffman

text ==

L'objectif de cet exercice est de créer un [codage de huffman](https://fr.wikipedia.org/wiki/Codage_de_Huffman). Il faut donc commencer par bien lire l'article wikipédia en lien.

Ressources disponibles:

- https://fr.wikipedia.org/wiki/Codage_de_Huffman
- http://lwh.free.fr/pages/algo/compression/huffman.html
- https://www.youtube.com/watch?v=UAY-wpHZCs4

==
