
extends=/template/default.pl

title =$% \underline{ Vos feedback } %$ 

text = Faites nous vos remarques sur cette feuille .

