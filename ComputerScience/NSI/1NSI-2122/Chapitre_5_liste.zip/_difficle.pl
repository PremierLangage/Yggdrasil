extends=/template/default.pl

title=**Section difficile**

text=Les exercices suivant pourraient être un peu plus difficiles.

form=
