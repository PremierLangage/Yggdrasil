extends=/template/default.pl

title =$% \underline{ Section } %$ 

text = les exercices suivant sont un peu plus difficiles.

form=


