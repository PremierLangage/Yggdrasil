# OCE : test 12/09/2019 OK

extends=/ComputerScience/python/AP1-1920/templates/looptemplate.pl

difficultymax=3
taboo=while
needed=for

title=Boucle while


plsoluce==
Exo Boucle while |
==




