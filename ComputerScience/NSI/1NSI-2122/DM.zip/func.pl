




extends = /ComputerScience/python/template/pltest.pl

title= Distribution 

text==


Ecrire une fonction **{{funcname}}** qui vérifie le doctest suivant :

{{doctest}}

[https://www.belote.com/regles-et-variantes/les-regles-de-la-belote-classique/  ](https://www.belote.com/regles-et-variantes/les-regles-de-la-belote-classique/)

==


pltest==
>>> deal([],3)
>>> deal([(1,2),(3,4)],1)
[(1,2)],[(3,4)]
==


