Création du fichier le 25/08/2021

Ceci est le document de travail pour la mouture 2021 du TP PLaTon correspondant aux notions vues au Chapitre 1 (Nommage Variables Input Affectation Conditionnelles).

Pour l'instant j'ai (OCE) fait une copie locale de la feuille de tp principale et une au fur et à mesure de leur traitement des exercices, pour que les modifications que l'on fait dans cette phase ne soient pas définitives.

**CONSIGNES:**

    - les _tags_ sont à séparer par des pipes sans espace : |
    - les _tags_ doivent être en minuscule et sans accent
    - la liste des _tags_ existant est dans le fichier "Liste_TAGS" regardez le avant d'en inventer un ou 
      de mal orthographier merci
    - Les auteurs sont systématiquement en commentaires en effet à moins que les élèves vous verse
      une part de leur argent de poche à chaque fois, ils n'ont pas besoin de savoir qui à pondu 
      l'exercice. PAR CONTRE il est essentiel de connaître l'auteur du source notamment si l'exo plante ou 
      qu'aucune correction n'est apparente !
      Donc : le tag "auteur" est important mais systématiquement en commentaire
    - n'hésitez pas à faire des commentaires/remarques/changements, que ce soit sur les exercices ou ce document
    - est-ce qu'il manque des concepts/notions à traiter / est-ce qu'on veut faire quelques exercices supplémentaires ?

Ci-dessous, une description de chaque exercice et des changements effectués par rapport à la mouture précédente (ainsi que quelques commentaires).

Tous les exercices ont été testé en exécution sous l'éditeur PL mais il y en a qui plante (signalé dans le source): 

    - expressionaleatoires-2122.pl
    - operateursbooleens-2122.pl
    - priority-2122.pl
