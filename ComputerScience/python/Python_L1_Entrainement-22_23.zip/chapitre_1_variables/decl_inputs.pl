



input0 =: Input
input0.type = text
input0.placeholder = Answer
input0.maxlength = 20
input0.appearance = outline


input1 =: Input
input1.type = text
input1.placeholder = Answer
input1.maxlength = 20
input1.appearance = outline



input2 =: Input
input2.type = text
input2.placeholder = Answer
input2.maxlength = 20
input2.appearance = outline


input3 =: Input
input3.type = text
input3.placeholder = Answer
input3.maxlength = 20
input3.appearance = outline

