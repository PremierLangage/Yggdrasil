
#author=zip

# Heritage d'un type d'exercice 
extends=/ComputerScience/python/template/soluce.pl

title = Rectangle fixe

tag = input|print|variable|type|operation

text== 
Les dimensions d'un rectangle sont 3 et 7.

Ecrire un programme qui calcule et affiche le périmètre et la surface du rectangle
sous la forme :

Le périmètre est ?? et la surface est ?? !
==
code==
"Le périmètre est ?? et la surface est ?? !"
==

soluce==
print("Le périmètre est 20 et la surface est 21 !")
==

plsoluce==
Le test |Le périmètre est 20 et la surface est 21 !
==





