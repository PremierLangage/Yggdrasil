
# DR j'ai fixé la seed dans cet exercice  
# il est donc statique

extends=/ComputerScience/python/AP1-1920/templates/looptemplate.pl
tag=InstructionsRepetitives|ForInRange


difficulty=2
taboo=while
needed=for

title=Boucle for (répétable) 1/3

text= Pour ne pas avoir un warning stupid

plsoluce==
Vérification du comportement fixé |
==






