extends=/template/default.pl

title=**Section difficile**

text=Les exercices suivant pourraient être un peu plus difficiles, mais tout à fait faisable avec ce que vous connaissez.

form=
