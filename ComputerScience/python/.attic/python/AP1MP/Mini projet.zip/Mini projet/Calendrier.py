j = int(input("Jour:"))
m = int(input("Mois:"))
a = int(input("Année:"))
j2 = int(31)			#nb jours dans le mois m

print("La date choisie est",j,"/",m,"/",a) 

if m==4 or m==6 or m==9 or m==11:
	if j>30:
		print("Numéro de jour incorrect:",j)
	j2 = j2-1
elif j>31 and m!=2:
	print("Numéro de jour incorrect:",j)
	
if 12<m or m<1:
	print("Numéro de mois incorrect :",m)

if (a%4==0 and a%100!=0) or a%400==0:
	b=1								#année bissextile			
	if m==2:
		if j>29:
			print("Numéro de jour incorrect:",j)
		j2 = j2-2
	print("L'année",a,"est bissextile")
else:
	b=0								#année non bissextile
	if m==2:
		if j>28:
			print("Numéro de jour incorrect:",j)
		j2 = j2-3
	print("L'année",a,"n'est pas bissextile")
print("Le mois",m,"/",a,"compte",j2,"jours.")

if m<=3 and j<=20:
	print("Cette date est en hiver")
elif m<=6 and j<=19:
	print("Cette date est en printemps")
elif m<=9 and j<=21:
	print("Cette date est en été")
elif m<=12 and j<=20:
	print("Cette date est en automne")
else:
	print("Cette date est en hiver")
	
TpsEcou = int((a-1)*365.2425)
print("Il s'est écoulé",TpsEcou,"jours entre le 1/1/1 et le 1/1/",a)

r=0
j3=0
while r<m-1:
	r=r+1
	if r in [4,6,9,11]:
		j3=j3+30
	elif r!=2:
		j3=j3+31
	elif b==1:
		j3=j3+29
	else:
		j3=j3+28
		
j4=TpsEcou+j3+j
print("Il s'est écoulé",j3,"jours entre 1/1/",a,"et le 1/",m,"/",a)
print("Le",j,"/",m,"/",a,"est le jour numéro",j3+j,"de l'année",a,".")
print("C'est le jour numéro",j4,"de notre ère.")

if ((a-1)%4==0 and (a-1)%100!=0) or (a-1)%400==0:
	j4=j4+1
	
s=1
s=s+((j3+j-1)//7)
if j4%7==1:
	print("C'est un lundi.")
	j5=1
elif j4%7==2:
	print("C'est un mardi.")
	j5=2
elif j4%7==3:
	print("C'est un mercredi.")
	j5=3
elif j4%7==4:
	print("C'est un jeudi.")
	j5=4
elif j4%7==5:
	print("C'est un vendredi.")
	j5=5
elif j4%7==6:
	print("C'est un samedi.")
	j5=6
else:
	print("C'est un dimanche.")
	j5=7
	
if s==53 and (j in [29,30,31]) and (j5 in [1,2,3]):			#si la semaine vaut 53 et que le jour est compris entre 29 et 31 et que c'est un lundi, mardi, jeudi.
	s=1														#Remettre le numéro de la semaine à 1.
	a=a+1													#Ajouter 1 à l'année.
elif s==52 and (j in [29,30,31]) and (j5 in [1,2,3]):		#si la semaine vaut 52 et que le jour est compris entre 29 et 31 et que c'est un lundi, mardi, jeudi.
	s=1														#Remettre le numéro de la semaine à 1.
	a=a+1													#Ajouter 1 à l'année.
	
print("C'est le jour",j5,"de la semaine",s,"de l'année ISO",a)
