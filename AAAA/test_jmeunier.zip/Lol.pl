extends = /model/basic/vraifaux.pl

title= Un exemple de proposition vraie ou fausse 

text==
Le cheval bleu de <span style="color:blue">Henri VIII</<span> est il blanc ? 
==


answer=Non


# pour aligner les propositions 
horizontal % true 

feedback_correct ==
Bien vu il est gris car il s'est roulé dans la poussière.  
<img src="https://cdn.icon-icons.com/icons2/2066/PNG/512/emoji_smile_icon_125296.png">
==
feedback_wrong = Il vous manque des informations.
general_feedback==



Bien entendu c'est une question piège.
==



