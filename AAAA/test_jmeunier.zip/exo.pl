extends=/model/basic/radio.pl

question ==
Ma question est généiale ?
==

items ==
Oui
Non
Peut-être
==

# paramètres optionnels
#  pour ne pas mélanger les items mettre shuffeld to false

shuffeld = false

# pour indiquer une autre bonne réponse que la BR par défaut, changer indsol
indsol = 1

