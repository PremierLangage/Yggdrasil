extends = /model/basic/sortlist.pl


sortedlist==
un
deux
trois
quatre
cinq
==



