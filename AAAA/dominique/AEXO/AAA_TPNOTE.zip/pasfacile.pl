



extends= splittemplate.pl

builder =@ bbefore.py

@ pasfacile.c [sujet.c]

title = EUh ?


