

extends= splittemplate.pl

@ in.c [sujet.c]
