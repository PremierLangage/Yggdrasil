

extends= splittemplate.pl

@ endswith.c [sujet.c]

