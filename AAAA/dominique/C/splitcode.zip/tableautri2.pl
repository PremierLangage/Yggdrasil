

extends= splittemplate.pl

@ tableautri2.c [sujet.c]


