

extends= splittemplate.pl

@ exercice2.c [sujet.c]


