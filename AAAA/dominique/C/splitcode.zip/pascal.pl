

extends= splittemplate.pl


@ pascal.c [sujet.c]

title = Si vous avez fini les autres exercices !