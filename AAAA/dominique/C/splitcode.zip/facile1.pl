


extends= splittemplate.pl

@ facile1.c [sujet.c]


title = facile1



