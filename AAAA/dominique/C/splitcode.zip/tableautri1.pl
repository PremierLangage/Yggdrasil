
extends= splittemplate.pl

@ tableautri.c [sujet.c]


