
extends= splittemplate.pl

@ exercice.c [sujet.c]
