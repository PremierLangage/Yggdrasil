




extends= splittemplate.pl

builder =@ bbefore.py

@ plusdur.c [sujet.c]

title = qsfdsqd


