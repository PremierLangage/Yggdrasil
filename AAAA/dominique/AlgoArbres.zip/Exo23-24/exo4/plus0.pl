





extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ plus0.c [sujet.c]

title = Plus dur



