




extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ ffhaut0.c [sujet.c]

title = Arbres N-aire fils gauche frère droit 


