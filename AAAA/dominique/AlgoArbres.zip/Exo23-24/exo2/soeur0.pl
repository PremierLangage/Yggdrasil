



extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ soeur0.c [sujet.c]

title = Arbre fille gauche, soeur droite 


