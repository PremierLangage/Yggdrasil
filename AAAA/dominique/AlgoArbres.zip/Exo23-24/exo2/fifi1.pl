


extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ fifi1.c [sujet.c]

title = Arbre fils gauche, frère droit 


