


extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ alloc2.c [sujet.c]

title = Allocation 


