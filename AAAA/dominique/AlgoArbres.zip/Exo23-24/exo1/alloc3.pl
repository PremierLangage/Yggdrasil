



extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ alloc3.c [sujet.c]

title = Allocation 


