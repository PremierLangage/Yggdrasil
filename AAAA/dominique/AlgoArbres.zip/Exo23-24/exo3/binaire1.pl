




extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ binaire1.c [sujet.c]

title = Arbres Binaires
