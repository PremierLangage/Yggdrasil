








extends= ../splittemplate.pl

builder =@ ../bbefore.py

@ binaire0.c [sujet.c]


title = Arbres Binaires