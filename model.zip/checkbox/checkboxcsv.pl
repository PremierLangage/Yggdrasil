
extends= /exemples/checkboxgroupcsv/model.pl

# pour fonctionner ce model utilise un fichier csv
# utilisant ';' comme séparateur 
# Avec deux colones target et source 
# @ /exemples/checkboxgroupcsv/maladies.csv  [content.csv] 

