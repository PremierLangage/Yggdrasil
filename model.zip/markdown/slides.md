
Premier Slide 

# Latex

$%\huge \frac{\sqrt{x^7}}{\pi^2} <= +\infty%$ 



***

# Slide 1

## Comment utiliser le lecteur de slides

Le markdown n'est pas encore complet mais cela viendra. 

    extends= /model/markdown/slideshow.pl
    @ monfichierdeslides.md [slides.md]


***


# Slide 2 

Pour séparer les slides les un des autres "***".


***

# Slide 3 

## titre de niveau 2 

La première ligne est un titre garder votre # (diese) pour pouvoir utiliser votre slide dans pandoc .


***

# Latex

$%\huge \frac{\sqrt{x^7}}{\pi^2} <= +\infty%$ 





