
extends = /model/matchlist/matchlist.pl

pairs ==
Nourriture pour chat§chat
Nourriture pour chien§chien
Nourriture pour oiseaux§oiseaux
==

text = Associer les bons annimaux au bonnes nourritures  

title = Nourrire vos animaux 

