

@ /builder/none.py [builder.py]
@ /grader/evaluator.py [grader.py]
@ /utils/builderlib.py



text==

==

form = /form/text_editor.html

evaluator==
grade=(100, "Merci pour votre retour")
==
