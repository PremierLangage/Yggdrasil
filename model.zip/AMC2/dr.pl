



extends= /model/AMC2/QCM-AMCE.pl

title= DR's Exo


text= 

questions==


* Radio : cick sur a
+ a
- b

** CheckBox  
    c=2<br/>
    print(c)<br/>

+ a
- b



==






