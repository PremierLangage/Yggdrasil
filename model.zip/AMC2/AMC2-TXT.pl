

extends= /model/AMC2/QCM-AMCE.pl

title= Fichiers de questions

onepergroup=true


text==
Bande moule 
    
==

questions=
@ exe.txt [question1.txt]
@ exe.txt [question2.txt]



